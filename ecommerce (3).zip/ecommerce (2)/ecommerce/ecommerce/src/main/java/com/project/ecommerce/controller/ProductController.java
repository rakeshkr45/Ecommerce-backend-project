package com.project.ecommerce.controller;

import com.project.ecommerce.common.ApiResponse;
import com.project.ecommerce.dto.ProductDTO;
import com.project.ecommerce.exceptions.ProductNotExistsException;
import com.project.ecommerce.model.Category;
import com.project.ecommerce.model.Product;
import com.project.ecommerce.repository.CategoryRepository;
import com.project.ecommerce.service.ProductService;
import com.project.ecommerce.service.WishListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/product")
public class ProductController {
    @Autowired
    ProductService productService;
    @Autowired
    WishListService wishListService;

    @Autowired
    CategoryRepository categoryRepository;

    @PostMapping("/add")
    public ResponseEntity<ApiResponse> createProduct (@RequestBody ProductDTO productDTO){
        Optional<Category> optionalCategory = categoryRepository.findById(productDTO.getCategoryId());
        if(!optionalCategory.isPresent()){
            return new ResponseEntity<ApiResponse>(new ApiResponse(false,"category does not exist"), HttpStatus.NOT_FOUND);
        }
        productService.createProduct(productDTO,optionalCategory.get());
        return new ResponseEntity<ApiResponse>(new ApiResponse(true,"product has been added"),HttpStatus.CREATED);
    }

    @GetMapping("/list")
    public ResponseEntity<List<ProductDTO>> getProducts() {
        List<ProductDTO> products = productService.getAllProducts();
        return new ResponseEntity<>(products,HttpStatus.OK);
    }

    @PutMapping("/update/{productId}")
    public ResponseEntity<ApiResponse> updateProduct (@PathVariable("productId") Integer productId, @RequestBody ProductDTO productDTO) throws Exception {
        if(!productService.findByid(productId)){
            return new ResponseEntity<ApiResponse>(new ApiResponse(false,"product does not exist"), HttpStatus.NOT_FOUND);
        }
        Optional<Category> optionalCategory = categoryRepository.findById(productDTO.getCategoryId());
        if(!optionalCategory.isPresent()) {
            return new ResponseEntity<ApiResponse>(new ApiResponse(false, "category does not exist"), HttpStatus.NOT_FOUND);
        }
        productService.updateProduct(productDTO,productId);
        return new ResponseEntity<ApiResponse>(new ApiResponse(true,"product has been updated"),HttpStatus.OK);
    }

    @DeleteMapping("/delete/{productId}")
    public ResponseEntity<ApiResponse> deleteProduct (@PathVariable("productId") Integer productId) throws Exception {
        if(!productService.findByid(productId)){
            return new ResponseEntity<ApiResponse>(new ApiResponse(false,"product does not exist"), HttpStatus.NOT_FOUND);
        }
        productService.deleteProduct(productId);
        return new ResponseEntity<ApiResponse>(new ApiResponse(true,"product has been deleted"),HttpStatus.OK);
    }

}
