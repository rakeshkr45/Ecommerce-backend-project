package com.project.ecommerce.dto.cart;

import com.project.ecommerce.model.CartItem;
import com.project.ecommerce.model.Product;

public class CartItemsDTO {

    private Integer id;
    private Integer quantity;
    private Product product; // Product info stored in CartItem

    public CartItemsDTO(CartItem cartItem) { // Fix: Use CartItem instead of Cart
        this.id = cartItem.getId();
        this.quantity = cartItem.getQuantity();
        this.product = cartItem.getProduct(); // Now correctly retrieves the product
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
}
