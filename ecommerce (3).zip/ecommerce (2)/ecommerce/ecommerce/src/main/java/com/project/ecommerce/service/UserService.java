package com.project.ecommerce.service;

import com.project.ecommerce.dto.ResponseDTO;
import com.project.ecommerce.dto.user.SignInDTO;
import com.project.ecommerce.dto.user.SignInResponseDTO;
import com.project.ecommerce.dto.user.SignupDTO;
import com.project.ecommerce.exceptions.AuthenticationFailException;
import com.project.ecommerce.exceptions.CustomException;
import com.project.ecommerce.model.AuthenticationToken;
import com.project.ecommerce.model.User;
import com.project.ecommerce.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

import java.security.MessageDigest;
import java.util.Objects;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    UserRepository userRepository;

    @Autowired
    AuthenticationService authenticationService;

    @Transactional
    public ResponseDTO signUp(SignupDTO signupDTO) {
        if(Objects.nonNull(userRepository.findByEmail(signupDTO.getEmail()))){
            throw new CustomException("user already exists");
        }

        String encryptedpassword = signupDTO.getPassword();

        try{
            encryptedpassword = hashPassword(signupDTO.getPassword());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
//            throw new CustomException(e.getMessage());
        }

        User user =new User(signupDTO.getFirstName(), signupDTO.getLastName(), signupDTO.getEmail(), encryptedpassword);

        userRepository.save(user);

        final AuthenticationToken authenticationToken = new AuthenticationToken(user);

        authenticationService.saveConfirmationToken(authenticationToken);

        ResponseDTO responseDTO = new ResponseDTO("success","user successfully registered!!");
        return responseDTO;
    }

    public static String printHexBinary(byte[] digest) {
        return HexFormat.of().formatHex(digest).toUpperCase();
    }

    private String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(password.getBytes());
        byte[] digest = md.digest();
        String hash = printHexBinary(digest);
        return hash;
    }

    public SignInResponseDTO signIn(SignInDTO signInDTO) {

        User user = userRepository.findByEmail(signInDTO.getEmail());

        if(Objects.isNull(user)){
            throw new AuthenticationFailException("user does not exist..");
        }

        try {
            if(!user.getPassword().equals(hashPassword(signInDTO.getPassword()))){
                throw new AuthenticationFailException("wrong login credentials..");
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        AuthenticationToken token = authenticationService.getToken(user);

        if(Objects.isNull(token)){
            throw new CustomException("token is not present..");
        }

        return new SignInResponseDTO("success", token.getToken());

    }

    public User findById(Integer userId) {
        Optional<User> optionalUser = userRepository.findById(userId);
        if(optionalUser.isEmpty()){
            return null;
        }
        return optionalUser.get();
    }
}
