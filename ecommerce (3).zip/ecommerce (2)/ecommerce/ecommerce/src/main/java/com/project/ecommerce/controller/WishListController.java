package com.project.ecommerce.controller;

import com.project.ecommerce.common.ApiResponse;
import com.project.ecommerce.dto.ProductDTO;
import com.project.ecommerce.model.Product;
import com.project.ecommerce.model.User;
import com.project.ecommerce.model.WishList;
import com.project.ecommerce.service.AuthenticationService;
import com.project.ecommerce.service.WishListService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/wishlist")
public class WishListController {

    @Autowired
    WishListService wishListService;

    @Autowired
    AuthenticationService authenticationService;

    @PostMapping("/add")
    public ResponseEntity<ApiResponse> addToWishList(@RequestBody Product product, @RequestParam("token") String token){

        authenticationService.authenticate(token);

        User user = authenticationService.getUser(token);

        WishList wishList = new WishList(user, product);

        wishListService.createWishList(wishList);

        ApiResponse apiResponse = new ApiResponse(true,"Added to wishlist!!");
        return new ResponseEntity<>(apiResponse, HttpStatus.CREATED);

    }

    @GetMapping("/list/{token}")
    public ResponseEntity<List<ProductDTO>> getFromWishList(@PathVariable("token") String token){

        authenticationService.authenticate(token);

        User user = authenticationService.getUser(token);

        List<ProductDTO> wishListForUser = wishListService.getWishListForUser(user);

        return new ResponseEntity<>(wishListForUser, HttpStatus.OK);

    }

    @DeleteMapping("/delete/{token}")
    @Transactional
    public ResponseEntity<ApiResponse> deleteWishList(@PathVariable("token") String token){

        authenticationService.authenticate(token);

        User user = authenticationService.getUser(token);

        wishListService.deleteWishListByUser(user);

        ApiResponse apiResponse = new ApiResponse(true,"Wishlist deleted!!");
        return new ResponseEntity<>(apiResponse, HttpStatus.OK);

    }

}
