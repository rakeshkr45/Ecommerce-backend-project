package com.project.ecommerce.service;

import com.project.ecommerce.dto.ProductDTO;
import com.project.ecommerce.exceptions.CustomException;
import com.project.ecommerce.exceptions.ProductNotExistsException;
import com.project.ecommerce.model.Category;
import com.project.ecommerce.model.Product;
import com.project.ecommerce.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    @Autowired
    ProductRepository productRepository;

    public void createProduct(ProductDTO productDTO, Category category) {
        Product product = new Product();
        product.setDescription(productDTO.getDescription());
        product.setImageURL(productDTO.getImageURL());
        product.setName(productDTO.getName());
        product.setCategory(category);
        product.setPrice(productDTO.getPrice());
        productRepository.save(product);
    }

    public ProductDTO getProductDTO(Product product){
        ProductDTO productDTO = new ProductDTO();
        productDTO.setDescription(product.getDescription());
        productDTO.setImageURL(product.getImageURL());
        productDTO.setName(product.getName());
        productDTO.setCategoryId(product.getCategory().getId());
        productDTO.setPrice(product.getPrice());
        productDTO.setId(product.getId());
        return productDTO;
    }

    public List<ProductDTO> getAllProducts() {
        List<Product> allProducts = productRepository.findAll();
        List<ProductDTO> productDTOs = new ArrayList<>();
        for(Product product:allProducts){
            productDTOs.add(getProductDTO(product));
        }
        return productDTOs;
    }

    public void updateProduct(ProductDTO productDTO, Integer productId) throws Exception {

        Optional<Product> optionalProduct = productRepository.findById(productId);

        if(!optionalProduct.isPresent()){
            throw new Exception("Product not present!!");
        }

        Product product = optionalProduct.get();

        product.setDescription(productDTO.getDescription());
        product.setImageURL(productDTO.getImageURL());
        product.setName(productDTO.getName());
        product.setPrice(productDTO.getPrice());
        productRepository.save(product);

    }

//    public Product findById(Integer productId) {
//        Optional<Product> optionalProduct = productRepository.findById(productId);
//        if(optionalProduct.isEmpty()){
//            throw new ProductNotExistsException("product id " + productId + " is invalid..");
//        }
//        return optionalProduct.get();
//    }

    public Product findById(Integer productId) {
        return productRepository.findById(productId)
                .orElseThrow(() -> new CustomException("Product not found with ID: " + productId));
    }

    public boolean findByid(Integer productId) {
        Optional<Product> optionalProduct = productRepository.findById(productId);
        if(optionalProduct.isEmpty()){
            return false;
        }
        return true;
    }

    public void deleteProduct(Integer productId) {
        productRepository.deleteById(productId);
    }
}
