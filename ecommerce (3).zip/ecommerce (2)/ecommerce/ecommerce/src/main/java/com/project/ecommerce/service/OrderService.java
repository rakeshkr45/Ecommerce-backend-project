package com.project.ecommerce.service;

import com.project.ecommerce.exceptions.CustomException;
import com.project.ecommerce.model.*;
import com.project.ecommerce.repository.CartRepository;
import com.project.ecommerce.repository.OrderRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CartService cartService;

    @Autowired
    private CartRepository cartRepository;

    // Get an order by its ID
    public Orders getOrderById(Integer orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
    }

    // Place an order from a user's cart
    @Transactional
    public Orders placeOrder(User user) {
        Cart cart = cartRepository.findByUser(user)
                .orElseThrow(() -> new CustomException("Cart not found"));

        if (cart.getCartItems().isEmpty()) {
            throw new CustomException("Cart is empty, cannot place order");
        }

        // Create new order
        Orders order = new Orders();
        order.setUser(user);
        order.setStatus("Order Placed");

        // Create a list of OrderItems and calculate total amount
        List<OrderItem> orderItems = new ArrayList<>();
        double totalAmount = 0;

        // Loop through cart items to convert them to order items
        for (CartItem cartItem : cart.getCartItems()) {
            OrderItem orderItem = new OrderItem();
            orderItem.setProduct(cartItem.getProduct());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setPrice(cartItem.getPrice());
            orderItem.setOrders(order); // Set the order reference to this order

            orderItems.add(orderItem);  // Add the order item to the list
            totalAmount += orderItem.getPrice() * orderItem.getQuantity(); // Update the total amount
        }

        // Set the total amount for the order
        order.setOrderItems(orderItems);
        order.setTotalAmount(totalAmount);

        // Save the order and its items
        Orders savedOrder = orderRepository.save(order);

        // Clear the cart after placing the order
        cartService.clearCart(user);

        return savedOrder;
    }

    public List<Orders> getOrdersByUser(User user) {
        return orderRepository.findByUser(user);
    }

}
