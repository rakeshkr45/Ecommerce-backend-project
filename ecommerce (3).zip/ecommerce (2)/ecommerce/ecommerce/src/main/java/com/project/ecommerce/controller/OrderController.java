package com.project.ecommerce.controller;

import com.project.ecommerce.model.Cart;
import com.project.ecommerce.model.Orders;
import com.project.ecommerce.model.User;
import com.project.ecommerce.service.AuthenticationService;
import com.project.ecommerce.service.CartService;
import com.project.ecommerce.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private CartService cartService;

    @Autowired
    private AuthenticationService authenticationService;

    @Autowired
    private OrderService orderService;

    @PostMapping("/place")
    public ResponseEntity<Orders> placeOrder(@RequestParam("token") String token) {

        // Authenticate the user
        authenticationService.authenticate(token);

        // Get the authenticated user
        User user = authenticationService.getUser(token);

        try {
            // Retrieve the user's cart (assuming CartService handles this now)
            Cart cart = cartService.getCartForUser(user);

            if (cart == null || cart.getCartItems().isEmpty()) {
                return ResponseEntity.badRequest().body(null);  // No items in the cart
            }

            // Place the order based on the user's cart
            Orders order = cartService.placeOrder(user, cart);  // You may need to pass the cart to placeOrder method

            // Set order status
            order.setStatus("Order Placed Successfully!");

            // Optionally, clear the cart after the order is placed
            cartService.clearCart(user);

            return ResponseEntity.ok(order);
        } catch (Exception e) {
            // Handle any exception and return a bad request response
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/user")
    public ResponseEntity<List<Orders>> getOrdersForUser(@RequestParam("token") String token) {
        authenticationService.authenticate(token);
        User user = authenticationService.getUser(token);

        List<Orders> orders = orderService.getOrdersByUser(user);
        return ResponseEntity.ok(orders);
    }

}