package com.project.ecommerce.controller;

import com.project.ecommerce.service.StripeService;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    @Autowired
    private StripeService stripeService;

    @Value("${stripe.api.key}")  // Injecting the Stripe API key from the properties file
    private String stripeApiKey;

    @PostConstruct
    public void init() {
        // Set the API key in the Stripe library
        Stripe.apiKey = stripeApiKey;
    }

    // Endpoint to create a payment intent
    @PostMapping("/create-intent")
    public ResponseEntity<Map<String, String>> createPaymentIntent(@RequestParam Long amount) {
        try {
            // Set up payment intent creation parameters
            Map<String, Object> params = new HashMap<>();
            params.put("amount", amount * 100); // amount in cents
            params.put("currency", "usd");
            params.put("payment_method_types", Collections.singletonList("card"));
            params.put("source", "tok_mastercard"); // Use tok_visa directly

            // Create PaymentIntent with test card token
            PaymentIntent paymentIntent = PaymentIntent.create(params);

            Map<String, String> response = new HashMap<>();
            response.put("clientSecret", paymentIntent.getClientSecret());
            response.put("paymentIntentId", paymentIntent.getId()); // Return the PaymentIntent ID as well

            return ResponseEntity.ok(response);
        } catch (StripeException e) {
            return ResponseEntity.badRequest().body(Collections.singletonMap("error", e.getMessage()));
        }
    }



    @PostMapping("/confirm-payment")
    public ResponseEntity<Map<String, String>> confirmPayment(@RequestParam String paymentIntentId) {
        try {
            // Retrieve the existing PaymentIntent using the provided ID
            PaymentIntent paymentIntent = PaymentIntent.retrieve(paymentIntentId);

            // Confirm the PaymentIntent
            PaymentIntent confirmedIntent = paymentIntent.confirm();

            Map<String, String> response = new HashMap<>();
            response.put("status", confirmedIntent.getStatus());
            response.put("id", confirmedIntent.getId());

            return ResponseEntity.ok(response);
        } catch (StripeException e) {
            return ResponseEntity.badRequest().body(Collections.singletonMap("error", e.getMessage()));
        }
    }


}

