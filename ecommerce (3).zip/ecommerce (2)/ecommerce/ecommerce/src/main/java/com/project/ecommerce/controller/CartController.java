package com.project.ecommerce.controller;

import com.project.ecommerce.common.ApiResponse;
import com.project.ecommerce.dto.cart.AddToCartDTO;
import com.project.ecommerce.dto.cart.CartDTO;
import com.project.ecommerce.model.User;
import com.project.ecommerce.service.AuthenticationService;
import com.project.ecommerce.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @Autowired
    private AuthenticationService authenticationService;

    @PostMapping("/add")
    public ResponseEntity<ApiResponse> addToCart(@RequestBody AddToCartDTO addToCartDTO, @RequestParam("token") String token){

        // Authenticate the user
        authenticationService.authenticate(token);

        // Get the user from the authentication service
        User user = authenticationService.getUser(token);

        // Add or update the cart item
        cartService.addToCart(addToCartDTO, user);

        return new ResponseEntity<>(new ApiResponse(true, "Added to Cart!"), HttpStatus.CREATED);
    }

    @GetMapping("/list")
    public ResponseEntity<CartDTO> getCartItems(@RequestParam("token") String token){
        // Authenticate the user
        authenticationService.authenticate(token);

        // Get the user from the authentication service
        User user = authenticationService.getUser(token);

        // List the cart items
        CartDTO cartDTO = cartService.listCartItems(user);

        return new ResponseEntity<>(cartDTO, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{cartItemId}")
    public ResponseEntity<ApiResponse> deleteCartItem(@PathVariable("cartItemId") Integer itemId, @RequestParam("token") String token){
        // Authenticate the user
        authenticationService.authenticate(token);

        // Get the user from the authentication service
        User user = authenticationService.getUser(token);

        // Delete the cart item
        cartService.deleteCartItem(itemId, user);

        return new ResponseEntity<>(new ApiResponse(true, "Item removed successfully!"), HttpStatus.OK);
    }
}

