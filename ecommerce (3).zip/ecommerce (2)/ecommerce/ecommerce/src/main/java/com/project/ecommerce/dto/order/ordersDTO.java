package com.project.ecommerce.dto.order;

public class ordersDTO {
}
