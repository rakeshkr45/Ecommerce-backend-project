package com.project.ecommerce.dto.cart;

import java.util.List;

public class CartDTO {

    private List<CartItemsDTO> cartItemsDTOS;
    private double totalCost;

    public CartDTO() {
    }

    public List<CartItemsDTO> getCartItemsDTOS() {
        return cartItemsDTOS;
    }

    public void setCartItemsDTOS(List<CartItemsDTO> cartItemsDTOS) {
        this.cartItemsDTOS = cartItemsDTOS;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }
}
