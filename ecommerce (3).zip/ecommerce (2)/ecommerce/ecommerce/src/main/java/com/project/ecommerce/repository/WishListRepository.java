package com.project.ecommerce.repository;

import com.project.ecommerce.model.Product;
import com.project.ecommerce.model.User;
import com.project.ecommerce.model.WishList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WishListRepository extends JpaRepository<WishList,Integer> {

    List<WishList> findAllByUserOrderByCreatedDateDesc(User user);

    void deleteByUser(User user);

}
