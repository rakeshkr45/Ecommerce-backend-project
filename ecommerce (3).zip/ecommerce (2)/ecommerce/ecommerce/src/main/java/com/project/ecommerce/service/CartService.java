package com.project.ecommerce.service;

import com.project.ecommerce.dto.cart.AddToCartDTO;
import com.project.ecommerce.dto.cart.CartDTO;
import com.project.ecommerce.dto.cart.CartItemRequestDTO;
import com.project.ecommerce.dto.cart.CartItemsDTO;
import com.project.ecommerce.exceptions.CustomException;
import com.project.ecommerce.model.*;
import com.project.ecommerce.repository.CartItemRepository;
import com.project.ecommerce.repository.CartRepository;
import com.project.ecommerce.repository.OrderRepository;
import com.project.ecommerce.repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private ProductService productService;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    // Add items to the cart (handles quantity update for existing items)
    public void addToCart(AddToCartDTO addToCartDTO, User user) {
        // Get or create user's cart
        Cart cart = cartRepository.findByUser(user)
                .orElseGet(() -> {
                    Cart newCart = new Cart();
                    newCart.setUser(user);
                    return cartRepository.save(newCart);
                });

        // Iterate through each item in DTO
        for (CartItemRequestDTO cartItemDTO : addToCartDTO.getCartItems()) {
            // Fetch the product using productId from CartItemRequestDTO
            Product product = productService.findById(cartItemDTO.getProductId());

            // Check if the product already exists in the cart
            Optional<CartItem> existingCartItem = cartItemRepository.findByCartAndProduct(cart, product);

            if (existingCartItem.isPresent()) {
                // If the product exists, update the quantity
                CartItem cartItem = existingCartItem.get();
                cartItem.setQuantity(cartItem.getQuantity() + cartItemDTO.getQuantity());  // Increase the quantity
                cartItem.setPrice(product.getPrice());  // Optional: Update the price if needed
                cartItem.setCreatedDate(new Date());  // Optional: Set new date for update

                cartItemRepository.save(cartItem);  // Save the updated cart item
            } else {
                // If the product doesn't exist in the cart, create a new CartItem
                CartItem cartItem = new CartItem();
                cartItem.setCart(cart);
                cartItem.setProduct(product);
                cartItem.setQuantity(cartItemDTO.getQuantity());
                cartItem.setPrice(product.getPrice());
                cartItem.setCreatedDate(new Date());

                cartItemRepository.save(cartItem);  // Save the new cart item
            }
        }
    }

    public Cart getCartForUser(User user) {
        // Retrieve the cart for the given user, or throw an exception if the cart doesn't exist
        return cartRepository.findByUser(user)
                .orElseThrow(() -> new CustomException("Cart not found for user: " + user.getId()));
    }


    // List all items in the user's cart
    public CartDTO listCartItems(User user) {
        // Get the user's cart, or throw an exception if none exists
        Cart cart = cartRepository.findByUser(user)
                .orElseThrow(() -> new CustomException("Cart not found"));

        // Retrieve all items in the cart
        List<CartItem> cartItems = cartItemRepository.findByCart(cart);
        List<CartItemsDTO> cartItemsDTOList = new ArrayList<>();
        double totalCost = 0;

        // Convert CartItem to CartItemsDTO
        for (CartItem cartItem : cartItems) {
            if (cartItem.getProduct() != null) { // Ensure product is not null
                CartItemsDTO cartItemsDTO = new CartItemsDTO(cartItem);
                totalCost += cartItem.getQuantity() * cartItem.getProduct().getPrice();
                cartItemsDTOList.add(cartItemsDTO);
            }
        }

        // Construct the response DTO
        CartDTO cartDTO = new CartDTO();
        cartDTO.setTotalCost(totalCost);
        cartDTO.setCartItemsDTOS(cartItemsDTOList);

        return cartDTO;
    }

    // Delete an item from the cart
    public void deleteCartItem(Integer itemId, User user) {
        CartItem cartItem = cartItemRepository.findById(itemId)
                .orElseThrow(() -> new CustomException("Cart item ID " + itemId + " is invalid."));

        // Ensure the cart item belongs to the user
        if (!cartItem.getCart().getUser().equals(user)) {
            throw new CustomException("Unauthorized deletion attempt for cart item: " + itemId);
        }

        cartItemRepository.delete(cartItem);
    }

    // Clear the user's cart
    @Transactional
    public void clearCart(User user) {
        Cart cart = cartRepository.findByUser(user).orElse(null);

        if (cart != null) {
            cartItemRepository.deleteAllByCart(cart); // Explicit deletion
            cartItemRepository.flush(); // Ensure items are removed from DB

            cartRepository.delete(cart); // Finally, delete the cart itself
        }
    }

    // Place an order from the cart items
    @Transactional
    public Orders placeOrder(User user, Cart cart) {
        cart = cartRepository.findByUser(user)
                .orElseThrow(() -> new CustomException("Cart not found"));

        if (cart.getCartItems().isEmpty()) {
            throw new CustomException("Cart is empty, cannot place order");
        }

        // Create new order
        Orders order = new Orders();
        order.setUser(user);
        order.setStatus("Order Placed");
        order.setOrderItems(new ArrayList<>());

        // Calculate the total amount and create order items
        double totalAmount = 0;
        for (CartItem cartItem : cart.getCartItems()) {
            OrderItem orderItem = new OrderItem();
            orderItem.setProduct(cartItem.getProduct());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setPrice(cartItem.getPrice());
            orderItem.setOrders(order);

            order.getOrderItems().add(orderItem);
            totalAmount += orderItem.getPrice() * orderItem.getQuantity();
        }

        order.setTotalAmount(totalAmount);

        // Save the order and order items
        Orders savedOrder = orderRepository.save(order);

        // Clear the cart after placing the order
        clearCart(user);

        return savedOrder;
    }
}
