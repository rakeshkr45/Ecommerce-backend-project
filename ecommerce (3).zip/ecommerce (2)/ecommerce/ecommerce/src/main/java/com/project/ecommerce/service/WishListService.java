package com.project.ecommerce.service;

import com.project.ecommerce.dto.ProductDTO;
import com.project.ecommerce.model.Product;
import com.project.ecommerce.model.User;
import com.project.ecommerce.model.WishList;
import com.project.ecommerce.repository.WishListRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class WishListService {

    @Autowired
    WishListRepository wishListRepository;

    @Autowired
    ProductService productService;

    public void createWishList(WishList wishList) {

        wishListRepository.save(wishList);

    }

    public List<ProductDTO> getWishListForUser(User user) {

        List<WishList> wishLists = wishListRepository.findAllByUserOrderByCreatedDateDesc(user);
        List<ProductDTO> productDTOList = new ArrayList<>();
        for(WishList wishList:wishLists){
            productDTOList.add(productService.getProductDTO(wishList.getProduct()));
        }

        return productDTOList;

    }


    public void deleteWishListByUser(User user) {
        wishListRepository.deleteByUser(user);
    }
}
