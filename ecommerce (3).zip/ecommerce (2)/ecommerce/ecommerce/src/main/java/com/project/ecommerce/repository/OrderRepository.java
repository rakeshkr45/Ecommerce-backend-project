package com.project.ecommerce.repository;

import com.project.ecommerce.model.Orders;
import com.project.ecommerce.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrderRepository extends JpaRepository<Orders, Integer> {
    List<Orders> findByUser(User user);
}

