package com.project.ecommerce.dto.cart;

import jakarta.validation.constraints.NotNull;
import java.util.List;

public class AddToCartDTO {

    @NotNull
    private List<CartItemRequestDTO> cartItems;

    public AddToCartDTO() {
    }

    public List<CartItemRequestDTO> getCartItems() {
        return cartItems;
    }

    public void setCartItems(List<CartItemRequestDTO> cartItems) {
        this.cartItems = cartItems;
    }
}
