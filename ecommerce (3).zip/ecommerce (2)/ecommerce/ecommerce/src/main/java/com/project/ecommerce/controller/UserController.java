package com.project.ecommerce.controller;

import com.project.ecommerce.dto.ResponseDTO;
import com.project.ecommerce.dto.user.SignInDTO;
import com.project.ecommerce.dto.user.SignInResponseDTO;
import com.project.ecommerce.dto.user.SignupDTO;
import com.project.ecommerce.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/user")
@RestController
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping("/signup")
    public ResponseDTO signup(@RequestBody SignupDTO signupDTO){
        return userService.signUp(signupDTO);
    }

    @PostMapping("/signin")
    public SignInResponseDTO signIn(@RequestBody SignInDTO signInDTO){
        return userService.signIn(signInDTO);
    }

}
